﻿double nota1, nota2, media;
Console.Write("Digite a primeira nota:");
nota1 = double.Parse(Console.ReadLine());
Console.Write("Digite a segunda nota:");
nota2 = double.Parse(Console.ReadLine());

media=(nota1 * 2 + nota2 * 3) / (2 + 3); //média ponderada
Console.WriteLine("A média ponderada é:" + media);
Console.ReadKey();
